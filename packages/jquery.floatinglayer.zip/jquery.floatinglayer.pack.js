/*
 * jQuery Floating Layer Plugin 1.0
 *
 * http://renjin.blogspot.com/2009/07/jquery-floating-layer-plugin.html
 * Author: renjin
 * Date: 2009-7-19
 *
 * Dual licensed under the MIT and GPL licenses:
 *  http://www.opensource.org/licenses/mit-license.php
 *  http://www.gnu.org/licenses/gpl.html
 */
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}(';(4($){$.N={O:{6:{x:\'c\',y:\'D\'},j:Z,l:\'Y\',n:q}};$.e($.r,{o:q});$(v).X(4(){8 5=$(\'<M></M>\').s({\'6\':\'n\',\'c\':\'L\',\'m\':\'L\'}).10(\'11\',\'13\').W().12(\'14\')[0];$.r.o=5.C==V||E(5.C)||5.C!=0?q:f;$(5).U()});$.T.e({S:4(g){k 1.I(4(){g=$.e({},$.N.O,g);3(1,g);$(1).s(\'6\',g.n&&$.r.o?\'n\':\'1d\').1g();1.J=f;p.h(1);8 B=1;$(F).1f(4(){p.h(B)}).15(4(){A.h(B)})})},1i:4(6){k 1.I(4(){9(1.J===f){3(1,$.e({},3(1),{6:6}));p.h(1)}})}});4 p(){3(1,$.e({},3(1),{K:P(1)}));A.h(1)}4 A(){8 6=3(1).K;8 7=w();8 x=6.x+7.x,y=6.y+7.y;9(!3(1).n){8 j=3(1).j;8 l=3(1).l;$(1).17({c:x+\'b\',m:y+\'b\'},{j:j,16:q,l:l})}a 9(!$.r.o){$(1).s({c:x+\'b\',m:y+\'b\'})}a{$(1).s({c:6.x+\'b\',m:6.y+\'b\'})}}4 P(5){8 7=w();8 x=3(5).6.x,y=3(5).6.y;8 G=Q($(5).1a(f)),H=Q($(5).18(f));9(/^1h$/i.d(x)){x=7.x+7.u-G}a 9(/^D$/i.d(x)){x=7.x+(7.u-G)/ 2} a 9 (/^c$/i.d(x)){x=0}9(/^m$/i.d(y)){y=0}a 9(/^D$/i.d(y)){y=7.y+(7.t-H)/ 2} a 9 (/^1j$/i.d(y)){y=7.y+7.t-H}k{x:E(x)?0:x,y:E(y)?0:y}}4 3(5,z){k z===1b?$.R(5,\'3\'):$.R(5,\'3\',z)}4 w(){k{x:$(v).19(),y:$(v).1e(),u:$(F).u(),t:$(F).t()}}})(1c);',62,82,'|this||settings|function|element|position|view|var|if|else|px|left|test|extend|true|options|call||duration|return|easing|top|fixed|positionFixed|initialize|false|support|css|height|width|document|viewport|||value|doFloat|me|offsetLeft|center|isNaN|window|elementWidth|elementHeight|each|isFloating|target|0px|div|floatLayer|defaults|computePosition|parseInt|data|makeFloating|fn|remove|null|hide|ready|swing|500|attr|id|appendTo|_divFixedPosition|body|scroll|queue|animate|outerHeight|scrollLeft|outerWidth|undefined|jQuery|absolute|scrollTop|resize|show|right|floatingPosition|bottom'.split('|'),0,{}))

