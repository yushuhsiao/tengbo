
### Install 
```sh
jam install jquery.render
```

### Usage
Please check the [jquery.render](http://sideroad.secret.jp/plugins/jQueryRender/)

