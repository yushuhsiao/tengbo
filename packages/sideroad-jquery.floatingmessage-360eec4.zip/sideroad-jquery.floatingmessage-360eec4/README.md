
### Install 
```sh
jam install jquery.floatingmessage
```

### Usage
Please check the [jquery.floatingmessage](http://sideroad.secret.jp/plugins/jQueryFloatingMessage/)

