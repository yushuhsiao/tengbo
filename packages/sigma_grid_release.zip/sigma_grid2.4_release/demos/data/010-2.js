{
	
data : [

["008","Crystal",6.84,86,0.29,0,0.3,"Other","Other","-"],
["014","Moissanite",31,41,0.01,1,0.05,"Branch","UPS","What?"],
["010","Emerald",26,26,0.37,1,0.3,"Customer","UPS","What?"],
["014","Moissanite",31,64,0.26,0,0.4,"Deliver Center","Other","Deliver to my home"],
["007","Coral",12,14,0.03,1,0.2,"Deliver Center","Other","Deliver to my home"],
["014","Moissanite",31,81,0.31,0,0.1,"Other","Fedex","Some notes"],
["006","Citrine",104,73,0.25,1,0.05,"Customer","Other","Deliver to my home"],
["002","Amber",56,61,0.1,1,0.3,"Deliver Center","Other","What?"],
["010","Emerald",26,95,0.2,1,0.05,"Deliver Center","WestUnion","What?"],
["003","Amethyst",24.8,61,0.18,0,0.05,"Other","Other","Some notes"],
["003","Amethyst",24.8,81,0.22,0,0.3,"Deliver Center","Fedex","What?"],
["002","Amber",56,66,0.38,0,0.2,"Other","UPS","Deliver to my home"],
["007","Coral",12,47,0.13,0,0.3,"Branch","WestUnion","Some notes"]
],
pageInfo : {totalRowNum:13},



exception:''

}