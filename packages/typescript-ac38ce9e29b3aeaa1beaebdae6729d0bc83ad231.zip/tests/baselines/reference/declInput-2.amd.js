var M;
(function (M) {
    var C = (function () {
        function C() { }
        return C;
    })();    
    var E = (function () {
        function E() { }
        return E;
    })();
    M.E = E;    
    var D = (function () {
        function D() { }
        D.prototype.m232 = function () {
            return null;
        };
        D.prototype.m242 = function () {
            return null;
        };
        D.prototype.m252 = function () {
            return null;
        };
        D.prototype.m26 = function (i) {
        };
        D.prototype.m262 = function (i) {
        };
        D.prototype.m3 = function () {
            return new C();
        };
        return D;
    })();
    M.D = D;    
})(M || (M = {}));