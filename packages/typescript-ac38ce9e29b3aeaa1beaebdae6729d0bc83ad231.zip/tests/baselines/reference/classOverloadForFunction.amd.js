var foo = (function () {
    function foo() { }
    return foo;
})();
;
function foo() {
}