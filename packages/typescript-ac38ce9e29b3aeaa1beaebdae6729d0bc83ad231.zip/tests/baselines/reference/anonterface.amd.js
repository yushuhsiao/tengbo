var M;
(function (M) {
    var C = (function () {
        function C() { }
        C.prototype.m = function (fn, n2) {
            return fn(n2);
        };
        return C;
    })();
    M.C = C;    
})(M || (M = {}));
var c = new M.C();
c.m(function (n) {
    return "hello: " + n;
}, 18);