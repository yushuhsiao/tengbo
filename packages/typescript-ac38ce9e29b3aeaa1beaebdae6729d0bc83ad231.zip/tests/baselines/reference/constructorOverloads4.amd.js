(new M.Function("return 5"))();
M.Function("yo");