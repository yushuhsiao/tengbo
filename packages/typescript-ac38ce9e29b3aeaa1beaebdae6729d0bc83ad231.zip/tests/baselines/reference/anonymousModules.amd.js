var ;
(function () {
    .foo = 1;
    var ;
    (function () {
        .bar = 1;
    })( || ( = {}));
    var bar = 2;
    var ;
    (function () {
        var x = .bar;
    })( || ( = {}));
})( || ( = {}));