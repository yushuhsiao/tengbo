var Variables;
(function (Variables) {
    var x = function bar(a, b, c) {
    };
    x(1, 2, 3);
})(Variables || (Variables = {}));