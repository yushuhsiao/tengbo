var foo = (function () {
    function foo(a) {
    }
    return foo;
})();