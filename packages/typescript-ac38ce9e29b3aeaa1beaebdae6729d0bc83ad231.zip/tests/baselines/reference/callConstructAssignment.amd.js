var foo;
var bar;
foo = bar;
bar = foo;