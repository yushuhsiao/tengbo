var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var s = ({
});
var x = {
};
var C1 = (function () {
    function C1() { }
    return C1;
})();
var C2 = (function (_super) {
    __extends(C2, _super);
    function C2() {
        _super.apply(this, arguments);

    }
    return C2;
})(C1);
var y1 = new C2();
var y2 = new C2();
var y3 = {
};