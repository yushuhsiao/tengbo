function foof(bar) {
    return bar;
}
;
var x = foof("s", null);