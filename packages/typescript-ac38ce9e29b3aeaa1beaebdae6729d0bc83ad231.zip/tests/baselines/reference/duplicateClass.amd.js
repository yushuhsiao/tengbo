var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Foo = (function () {
    function Foo() { }
    return Foo;
})();
var Foo = (function (_super) {
    __extends(Foo, _super);
    function Foo() {
        _super.call(this);
    }
    return Foo;
})(Bar);