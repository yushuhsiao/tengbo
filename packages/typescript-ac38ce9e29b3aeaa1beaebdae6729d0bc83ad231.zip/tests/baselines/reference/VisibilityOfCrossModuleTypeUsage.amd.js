////[commands.js]
define(["require", "exports"], function(require, exports) {
    
    
})
////[fs.js]
define(["require", "exports"], function(require, exports) {
    
    function run(configuration) {
        var absoluteWorkspacePath = configuration.workspace.toAbsolutePath(configuration.server);
    }
})
////[server.js]
define(["require", "exports"], function(require, exports) {
})