var na = new Array();
var C = (function () {
    function C() { }
    return C;
})();
new Array();
var ba = new Array();
var sa = new Array();
function f(s) {
    return 0;
}
if(ba[14]) {
    na[2] = f(sa[3]);
}