var n = {
    w: null,
    x: '',
    y: function () {
    },
    z: 32
};