var myVar;
var strArray = [
    myVar.voidFn()
];
var myArray;
myArray = [
    [
        1, 
        2
    ]
];