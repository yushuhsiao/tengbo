var M;
(function (M) {
    var x = {
        salt: 2,
        pepper: 0
    };
})(M || (M = {}));