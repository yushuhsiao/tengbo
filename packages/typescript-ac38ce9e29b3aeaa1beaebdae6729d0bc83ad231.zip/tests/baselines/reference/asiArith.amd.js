var x = 1;
var y = 1;
var z = x + +(+y);
var a = 1;
var b = 1;
var c = x - -(-y);