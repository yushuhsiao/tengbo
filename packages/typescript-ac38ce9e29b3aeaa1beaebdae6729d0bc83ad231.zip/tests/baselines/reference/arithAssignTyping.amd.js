var f = (function () {
    function f() { }
    return f;
})();
f += '';
f += 1;
f -= 1;
f *= 1;
f /= 1;
f %= 1;
f &= 1;
f |= 1;