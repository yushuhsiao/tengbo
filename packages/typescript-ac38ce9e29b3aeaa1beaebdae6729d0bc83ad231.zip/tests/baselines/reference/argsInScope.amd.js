var C = (function () {
    function C() { }
    C.prototype.P = function (ii, j, k) {
        for(var i = 0; i < arguments.length; i++) {
        }
    };
    return C;
})();
var c = new C();
c.P(1, 2, 3);