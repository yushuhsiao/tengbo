var test = (function () {
    function test() {
    }
    return test;
})();