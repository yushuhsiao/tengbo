var f = (function () {
    function f() { }
    return f;
})();
f += '';