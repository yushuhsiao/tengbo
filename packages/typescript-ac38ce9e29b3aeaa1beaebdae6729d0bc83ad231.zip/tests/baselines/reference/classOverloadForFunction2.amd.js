var bar = (function () {
    function bar() { }
    return bar;
})();