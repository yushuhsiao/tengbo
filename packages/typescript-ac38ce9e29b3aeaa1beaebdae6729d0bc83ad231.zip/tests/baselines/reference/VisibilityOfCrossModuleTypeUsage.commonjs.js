////[commands.js]


////[fs.js]

function run(configuration) {
    var absoluteWorkspacePath = configuration.workspace.toAbsolutePath(configuration.server);
}