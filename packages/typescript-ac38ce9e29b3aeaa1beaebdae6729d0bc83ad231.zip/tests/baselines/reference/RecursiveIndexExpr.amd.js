var t = function () {
    var k = k[0];
};
var g = function () {
    var j;
    var k2 = j[k2];
};
function f(g) {
}
;
function h() {
    f(function () {
        var k = {
        }[''].forEach(function () {
            k['any property'];
        });
    });
}