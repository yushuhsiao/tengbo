var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var ab = A.B;
var D = (function (_super) {
    __extends(D, _super);
    function D() {
        _super.apply(this, arguments);

    }
    return D;
})(ab.C);
var E = (function (_super) {
    __extends(E, _super);
    function E() {
        _super.apply(this, arguments);

    }
    return E;
})(A.B.C);