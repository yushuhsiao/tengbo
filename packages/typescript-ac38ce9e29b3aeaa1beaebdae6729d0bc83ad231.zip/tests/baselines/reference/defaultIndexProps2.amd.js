var Foo = (function () {
    function Foo() {
        this.v = "Yo";
    }
    return Foo;
})();
var f = new Foo();
var o = {
    v: "Yo2"
};
1[0];
var q = "s"[0];