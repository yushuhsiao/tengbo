
var s1 = D();
var s2 = (new D(1))();