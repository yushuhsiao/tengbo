;
Foo.Bar.foo = 5;