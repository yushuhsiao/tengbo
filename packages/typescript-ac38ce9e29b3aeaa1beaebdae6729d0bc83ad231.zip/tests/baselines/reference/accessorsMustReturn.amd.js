var C = (function () {
    function C() { }
    Object.defineProperty(C.prototype, "yo", {
        get: function () {
        },
        enumerable: true,
        configurable: true
    });
    return C;
})();