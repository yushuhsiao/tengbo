Foo.a();
Foo.b;
var c = new Foo.C();
Foo2.a();
Foo2.b;
var c2 = new Foo2.C();