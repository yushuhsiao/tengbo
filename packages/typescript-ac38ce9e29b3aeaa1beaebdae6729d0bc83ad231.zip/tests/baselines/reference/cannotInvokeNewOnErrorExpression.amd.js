var M;
(function (M) {
    var ClassA = (function () {
        function ClassA() { }
        return ClassA;
    })();    
})(M || (M = {}));
var t = ;