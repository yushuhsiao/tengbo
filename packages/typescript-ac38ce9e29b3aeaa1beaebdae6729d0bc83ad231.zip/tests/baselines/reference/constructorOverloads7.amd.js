
function Point(x, y) {
    this.x = x;
    this.y = y;
    return this;
}
function EF1(a, b) {
    return a + b;
}