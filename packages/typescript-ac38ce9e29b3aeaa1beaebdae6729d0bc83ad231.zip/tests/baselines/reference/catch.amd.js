function f() {
    try  {
    } catch (e) {
    }
    try  {
    } catch (e) {
    }
}