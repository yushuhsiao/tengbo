var M;
(function (M) {
    var C = (function () {
        function C() { }
        return C;
    })();
    M.C = C;    
})(M || (M = {}));