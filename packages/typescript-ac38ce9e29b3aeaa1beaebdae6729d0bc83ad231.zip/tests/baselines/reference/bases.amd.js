var __extends = this.__extends || function (d, b) {
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var B = (function () {
    function B() {
        this.y;
        ;
        any;
    }
    return B;
})();
var C = (function (_super) {
    __extends(C, _super);
    function C() {
        this.x;
        ;
        any;
    }
    return C;
})(B);
new C().x;
new C().y;