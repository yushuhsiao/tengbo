debugger;

function foo() {
    debugger;

}