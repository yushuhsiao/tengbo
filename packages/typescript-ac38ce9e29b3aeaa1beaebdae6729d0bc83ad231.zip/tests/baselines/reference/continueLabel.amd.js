label1:
for(var i = 0; i < 1; i++) {
    continue label1;
}