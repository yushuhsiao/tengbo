var A = (function () {
    function A() { }
    return A;
})();