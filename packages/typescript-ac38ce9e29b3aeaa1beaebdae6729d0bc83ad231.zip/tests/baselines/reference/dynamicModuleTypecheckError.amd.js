define(["require", "exports"], function(require, exports) {
    exports.x = 1;
    for(var i = 0; i < 30; i++) {
        exports.x = i * 1000;
    }
})