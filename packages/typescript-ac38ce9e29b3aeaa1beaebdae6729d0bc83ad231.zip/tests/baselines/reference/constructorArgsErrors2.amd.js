var foo = (function () {
    function foo(a) {
        this.a = a;
    }
    return foo;
})();