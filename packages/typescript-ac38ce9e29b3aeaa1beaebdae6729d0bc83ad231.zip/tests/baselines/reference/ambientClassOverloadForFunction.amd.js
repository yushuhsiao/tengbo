
;
function foo() {
    return null;
}