var C3 = (function () {
    function C3() { }
    C3.prototype.CM3M1 = function () {
        return 3;
    };
    return C3;
})();
var c3 = new C3();
var o1 = {
    one: 1
};
var arr_any = [];
arr_any = function () {
    return null;
};
arr_any = c3;