# TypeScript

Scalable JavaScript development with types, classes and modules.

## Install

  npm install -g typescript

## Usage

  tsc hello.ts
  