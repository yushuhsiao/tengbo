===== TypeScript Sample: AMD Module =====

=== Overview ===
This sample shows a simple Typescript application using an AMD module.

=== Running ===
tsc --module amd app.ts
start default.htm


