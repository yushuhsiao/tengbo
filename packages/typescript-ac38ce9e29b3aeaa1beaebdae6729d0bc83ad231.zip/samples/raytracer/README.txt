===== TypeScript Sample: Raytracer =====

=== Overview ===

This sample shows a raytracer implementation in TypeScript.

=== Running ===
tsc raytracer.ts
start raytracer.html
