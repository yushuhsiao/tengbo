///<reference path='Position.ts'/>
///<reference path='Geometry.ts'/>
///<reference path='Game.ts'/>
///<reference path='Features.ts'/>
///<reference path='base.ts'/>

if (!this.document) {
    var game = new Mankala.Game();
    game.test();
}
