===== TypeScript Sample: Warship Combat =====

=== Overview ===

The classic grid-based warship combat game
- Use of the jQuery and jQuery UI wrappers
- Use of object-oriented techniques


=== Running ===
tsc --target ES5 warship.ts
start default.html
