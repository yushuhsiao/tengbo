===== TypeScript Sample: Greeter =====

=== Overview ===

This sample shows basic class definition and instantiation.

=== Running ===
tsc greeter.ts
start greeter.html
