///<reference path='..\..\..\..\..\typings\winrt.d.ts' static='true' />
///<reference path='..\..\..\..\..\typings\winjs.d.ts' static='true' />

declare var msSetImmediate: (expression: any) => void;



