
### Install 
```sh
jam install jquery.sidebar
```

### Usage
Please check the [jquery.sidebar](http://sideroad.secret.jp/plugins/jQuerySideBar/)

