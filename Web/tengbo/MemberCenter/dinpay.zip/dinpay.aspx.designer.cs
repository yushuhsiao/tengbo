﻿//------------------------------------------------------------------------------
// <自動產生的>
//     這段程式碼是由工具產生的。
//
//     對這個檔案所做的變更可能會造成錯誤的行為，而且如果重新產生程式碼，
//     所做的變更將會遺失。 
// </自動產生的>
//------------------------------------------------------------------------------



public partial class dinpay_aspx {
    
    /// <summary>
    /// Head1 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlHead Head1;
    
    /// <summary>
    /// DinpayAspVirForm 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlForm DinpayAspVirForm;
    
    /// <summary>
    /// M_ID 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden M_ID;
    
    /// <summary>
    /// MOrderID 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden MOrderID;
    
    /// <summary>
    /// MOAmount 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden MOAmount;
    
    /// <summary>
    /// MOCurrency 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden MOCurrency;
    
    /// <summary>
    /// M_URL 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden M_URL;
    
    /// <summary>
    /// M_Language 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden M_Language;
    
    /// <summary>
    /// S_Name 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden S_Name;
    
    /// <summary>
    /// S_Address 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden S_Address;
    
    /// <summary>
    /// S_PostCode 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden S_PostCode;
    
    /// <summary>
    /// S_Telephone 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden S_Telephone;
    
    /// <summary>
    /// S_Email 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden S_Email;
    
    /// <summary>
    /// R_Name 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden R_Name;
    
    /// <summary>
    /// R_Address 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden R_Address;
    
    /// <summary>
    /// R_PostCode 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden R_PostCode;
    
    /// <summary>
    /// R_Telephone 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden R_Telephone;
    
    /// <summary>
    /// R_Email 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden R_Email;
    
    /// <summary>
    /// MOComment 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden MOComment;
    
    /// <summary>
    /// MODate 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden MODate;
    
    /// <summary>
    /// State 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden State;
    
    /// <summary>
    /// digestinfo 控制項。
    /// </summary>
    /// <remarks>
    /// 自動產生的欄位。
    /// 將移動欄位宣告從設計檔案修改為程式碼後置檔案。
    /// </remarks>
    protected global::System.Web.UI.HtmlControls.HtmlInputHidden digestinfo;
}
