﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BU;
using web;
using System.Data.SqlClient;
using System.Web.Security;

public partial class dinpay_aspx : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!web.dinpay.CurrentConfig.Enabled) return;
        dinpay.config dinpay_config = dinpay.GetConfig(Member.Manager.DefaultCorpID);
        Member member = HttpContext.Current.User as Member;
        decimal? amount = Request.Form["n1"].ToDecimal();
        if (!amount.HasValue)
        {
            Response.StatusCode = (int)System.Net.HttpStatusCode.Forbidden;
            return;
        }
        using (SqlCmd sqlcmd = DB.Open(DB.Name.Main, DB.Access.ReadWrite))
        {
            MemberRow memberRow = member.GetMemberRow(sqlcmd, true, "Name", "Tel", "Mail");
            MemberTranRow tranRow = new web.dinpay() { LogType = BU.LogType.Dinpay, MemberID = member.ID, Amount1 = amount, }.Insert(null, sqlcmd);

            DinpayAspVirForm.Action = dinpay_config.action;
            M_ID.Value = dinpay_config.M_ID;                                           //<----商家号-------->
            MODate.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");        //<---不可以为空的--->
            string id_str = Convert.ToBase64String(tranRow.ID.Value.ToByteArray()); ;
            MOrderID.Value = id_str.Substring(0, id_str.Length - 2);
            //<----定单号-------->
            MOAmount.Value = tranRow.Amount1.ToString();                           //<----定单金额------> 
            MOCurrency.Value = "1";                                             //<----币种-默认为1---->
            M_URL.Value = dinpay_config.M_URL;                                         //<--返回地址-此项默认为空不起作用-->
            M_Language.Value = "1";
            S_Name.Value = "test1";
            S_Address.Value = "dinpay";
            S_PostCode.Value = "518000";
            S_Telephone.Value = "0755-88833166";
            S_Email.Value = "service@dinpay.com";
            R_Name.Value = "test2";
            R_Address.Value = "dinpay";
            R_PostCode.Value = "518000";
            R_Telephone.Value = "0755-82384511";
            R_Email.Value = "service@dinpay.com";
            MOComment.Value = "dinpay";
            State.Value = "0";

            string OrderMessage = M_ID.Value + MOrderID.Value + MOAmount.Value + MOCurrency.Value + M_URL.Value + M_Language.Value + S_PostCode.Value + S_Telephone.Value + S_Email.Value + R_PostCode.Value + R_Telephone.Value + R_Email.Value + MODate.Value + dinpay_config.Key;
            //Response.Write("串起来的订单信息为：" + OrderMessage + "<br>");
            string digest = FormsAuthentication.HashPasswordForStoringInConfigFile(OrderMessage, "md5").Trim().ToUpper();
            //Response.Write("加密认证为：" + digest);
            digestinfo.Value = digest;
        }
    }
}