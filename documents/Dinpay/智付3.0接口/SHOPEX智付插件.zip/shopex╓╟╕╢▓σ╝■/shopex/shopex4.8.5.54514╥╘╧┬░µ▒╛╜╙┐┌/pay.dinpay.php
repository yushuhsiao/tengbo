<?php
require('paymentPlugin.php');
class pay_dinpay extends paymentPlugin{

    var $name = '智付网上支付';//智付网上支付
    var $logo = 'dinpay';
    var $version = 20120305;
    var $charset = 'gb2312';
    var $submitUrl = 'https://pay.dinpay.com/PHPReceiveMerchantAction.do'; //  
    var $submitButton = ''; ##需要完善的地方
    var $supportCurrency = array("CNY"=>"1");
    var $supportArea = array("AREA_CNY");
    var $desc = '智付作为国内B2C电子商务网站中最早、最专业、最具规模的公司之一，目前拥有国内极其完善的银行卡在线实时支付平台和数字商品电子商务运营经验。含银联支付、手机支付、智游卡支付、交易更安全、快捷、方便，推荐使用。';
    var $orderby = 88;
   

    function toSubmit($payment){
		$m_id		=	$this->getConf($payment["M_OrderId"], 'member_id');
		$m_orderid	=	$payment["M_OrderId"];;
		$m_oamount	=	$payment["M_Amount"];;
		$m_ocurrency    ='1';
		$m_url		=	$this->callbackUrl;
		$m_language	=	'1';
		$s_name		=	' ';
		$s_addr		=	' ';
		$s_postcode	=	' ';
		$s_tel		=	' ';
		$s_eml		=	' ';
		$r_name		=	' ';
		$r_addr		=	' ';
		$r_postcode	=	' ';
		$r_tel		=	' ';
		$r_eml		=	' ';
		$m_ocomment	=	' ';
		date_default_timezone_set('PRC');
		$modate		=	date('Y-m-d H:i:s');
		$m_status	= 	0;
		
		
		//组织订单信息
		$m_info = $m_id."|".$m_orderid."|".$m_oamount."|".$m_ocurrency."|".$m_url."|".$m_language;
		$s_info = $s_name."|".$s_addr."|".$s_postcode."|".$s_tel."|".$s_eml;
		$r_info = $r_name."|".$r_addr."|".$r_postcode."|".$r_tel."|".$r_eml."|".$m_ocomment."|".$m_status."|".$modate;
	
		$OrderInfo = $m_info."|".$s_info."|".$r_info;

		$key = $this->getConf($payment["M_OrderId"], 'PrivateKey');
		
		 $hex="";
		 for ($i=0;$i<strlen($OrderInfo);$i++)
			 $hex.=dechex(ord($OrderInfo[$i]));
		 $hex=strtoupper($hex);
		 
		
		$OrderInfo = $hex;
		$digest = strtoupper(md5($OrderInfo.$key));
		
		$return["M_ID"] = $m_id;
        $return["digest"] = $digest;
        $return["OrderMessage"] = $OrderInfo;
		
        return $return;
    }

    function callback($in,&$paymentId,&$money){   
		
		 $OrderInfo=$in['OrderMessage'];
		 $signMsgs=$in['Digest'];
		 $key='xxxxxxx'; //支付密钥
		$digest = strtoupper(md5($OrderInfo.$key));
		if ($digest == $signMsgs)
		{
				$string='';
				for ($i=0;$i<strlen($OrderInfo)-1;$i+=2)
					 $string.=chr(hexdec($OrderInfo[$i].$OrderInfo[$i+1]));
				$OrderInfo =$string;
				$parm=explode("|", $OrderInfo);
				
				$paymentId =$parm[1];	
				$money=$parm[2];
				
				$m_id		= 	$parm[0];				
				$m_orderid	= 	$parm[1];		
				$m_oamount	= 	$parm[2];			
				$m_ocurrency= 	$parm[3];				
				$m_language	= 	$parm[4];			
				$s_name		= 	$parm[5];				
				$s_addr		= 	$parm[6];				
				$s_postcode	= 	$parm[7];		
				$s_tel		= 	$parm[8];			
				$s_eml		= 	$parm[9];			
				$r_name		= 	$parm[10];			
				$r_addr		= 	$parm[11];				
				$r_postcode	= 	$parm[12];			
				$r_tel		= 	$parm[13];			
				$r_eml		= 	$parm[14];			
				$m_ocomment	= 	$parm[15];
				$modate		=	$parm[16];
				$State		=	$parm[17];
				if ($State == 2)
					{	
						
						return PAY_SUCCESS;
					}
				else 
					{
						echo '支付失败';
						 return PAY_FAILED;
					}	
			
		   } else{
      	        echo '验签失败!订单已被人为修改';
				 return PAY_FAILED;
    	   }
    }

    function getfields(){
        return array(
                'member_id'=>array(
                        'label'=>'客户号',
                        'type'=>'string'
                    ),
                'PrivateKey'=>array(
                        'label'=>'私钥',
                        'type'=>'string'
                ),
            );
    }
}
?>
