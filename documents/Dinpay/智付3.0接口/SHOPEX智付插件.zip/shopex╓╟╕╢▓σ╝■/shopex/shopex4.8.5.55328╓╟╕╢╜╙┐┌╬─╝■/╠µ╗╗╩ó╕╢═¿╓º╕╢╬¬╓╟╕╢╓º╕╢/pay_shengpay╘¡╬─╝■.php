<?php
require('paymentPlugin.php');
require('pay_sign.php');
class pay_shengpay extends paymentPlugin{

    var $name = '盛付通[即时到账]';
    var $logo = 'shengpay';
    var $version = 2011830;
    var $charset = 'GB2312';
    //var $submitUrl = 'http://pre.netpay.sdo.com/paygate/default.aspx'; //测试请求地址：
    var $submitUrl = 'http://netpay.sdo.com/paygate/default.aspx'; //正式请求地址：
    var $submitButton = 'http://img.shengpay.com/pimg/button_shengpaybutton_o_a.gif'; ##需要完善的地方
    var $desc = '财付通是腾讯公司为促进中国电子商务的发展需要，满足互联网用户价值需求，针对网上交易安全而精心推出的一系列服务。';
    var $intro = '  盛付通网站（www.shengpay.com），国内领先的第三方支付平台，由盛大集团创办。
盛付通即时到账，费率0.5%-1%，个性费率签约独享。<br/><a href="http://bbs.shopex.cn/read.php?tid=228470&page=1&toread=1">点击帮助</a>';
    var $supportCurrency = array("CNY"=>"01");
    var $supportArea =  array("AREA_CNY");
    var $orderby = 4;

    function toSubmit($payment){
        $merId  = $this->getConf($payment['M_OrderId'], 'member_id'); //帐号
        $MD5Key = $this->getConf($payment['M_OrderId'], 'PrivateKey'); //密钥
        $PayChannel = $this->getConf($payment['M_OrderId'], 'PayChannel');//支付渠道
        $amount = number_format($payment['M_Amount'],2,".","");//订单金额
        $payment['T_time'] = $payment['T_time']?$payment['T_time']:time();
        $createtime = date('YmdHis',$payment['M_Time']);
        $ret_url = $this->callbackUrl;
        $server_url = $this->serverCallbackUrl;
        //组合接口需要的参数
        $return['Version']        = "3.0";                  //版本号
        $return['Amount']         = $amount;                //支付金额
        $return['OrderNo']        = $payment['M_OrderNO'];  //商户订单号
        $return['MerchantNo']     = $merId;                 //商户号 由盛付通商务人员提供
        $return['PayChannel']     = $PayChannel;             //PayChannel支付渠道 增加多个渠道请用逗号“，”隔开。
        $return['PostBackUrl']    = $ret_url;               //回调地址 显示给终端用户的地址
        $return['NotifyUrl']      = $server_url;            //发货地址 服务器端发货通知接口
        //$return['BackUrl']        = $server_url;
        $return['OrderTime']      = $createtime;            //订单日期必须为14位，格式: yyyyMMddHHmmss
        $return['CurrencyType']   = "RMB";                  //货币类型必须为：RMB
        $return['NotifyUrlType']  = "http";                 //发货通知方式http,https,tcp等
        $return['SignType']       = "2";                    //签名类型1:RSA 2:MD5 3:PKI
        //$return['ProductNo']      = "2"; 
        //$return['ProductDesc']    = "2"; 
        $return['Remark1']        = $payment['M_OrderId'];
        $return['Remark2']        = $payment['M_Remark'];
        $return['BankCode']       = "SDTBNK";               //默认银行，非必填，用户支付渠道时默认选中该银行。测试SDTBNK  
        //$return['DefaultChannel']       = "03";               //默认银行，非必填，用户支付渠道时默认选中该银行。测试SDTBNK  
        $tosignstring = implode("",$return);
        $return['MAC'] =  md5($tosignstring.$MD5Key);       //MD5Key加密串由盛付通提供的签名组件加密
        return $return;
    }

    function callback($in,&$paymentId,&$money,&$message,&$tradeno){
        $merId  = $this->getConf($in['Remark1'], 'member_id'); //帐号
        $MD5Key = $this->getConf($in['Remark1'], 'PrivateKey'); //密钥
        $signObj = new pay_sign;
        $checkResult = $signObj->checksign($in,$MD5Key);
        if($checkResult){
            $paymentId = $in['Remark1'];
            $money = $in['Amount'];
            $tradeno = $in['OrderNo'];
            $Status = $in['Status'];
            if ($Status=="01"){
                echo "OK";
                $message = "支付成功！";
                return PAY_SUCCESS;
            }else{
                $message = "支付失败！";
                return PAY_FAILED;
            }
         }else{
                $message = "验证签名错误！";
                return PAY_ERROR;
         }
    }
    function getfields(){
        return array(
                'member_id'=>array(
                        'label'=>'客户号',
                        'type'=>'string'
                    ),
                'PrivateKey'=>array(
                        'label'=>'私钥',
                        'type'=>'string'
                ),
                'PayChannel'=>array(
                        'label'=>'支付渠道',
                        'type'=>'string'
                ),
            );
    }
}
?>
